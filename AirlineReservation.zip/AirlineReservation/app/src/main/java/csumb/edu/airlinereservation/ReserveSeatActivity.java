/**
 * Author: Eric Orozco Viscarra
 * Abstract: Allows user to reserve a seat on a flight
 * 12/16/18
 */
package csumb.edu.airlinereservation;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import csumb.edu.airlinereservation.Database.LoginHelper;

public class ReserveSeatActivity extends AppCompatActivity {
    Spinner departure;
    Spinner arrival;
    Button submitButton;
    TextView results;
    TextView numTickets;
    FlightItem flightItem;
    Flight flight;
    LoginItem loginItem;
    Login login;
    EditText editUsername;
    EditText editPassword;
    Context mContext;
    LoginHelper mLoginHelper;
    TextView info;
    TextView textView3;
    TextView textView7;
    TextView textView8;
    Button submitButton2;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve_seat);

        submitButton2 = findViewById(R.id.submitButton2);
        info = findViewById(R.id.info);
        textView3 = findViewById(R.id.textView3);
        textView7 = findViewById(R.id.textView7);
        textView8 = findViewById(R.id.textView8);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        editUsername.setVisibility(View.INVISIBLE);
        editPassword.setVisibility(View.INVISIBLE);
        submitButton2.setVisibility(View.INVISIBLE);

        login = Login.get(this.getApplicationContext());
        flight = Flight.get(this.getApplicationContext());
        departure = (Spinner) findViewById(R.id.departure);
        arrival = (Spinner) findViewById(R.id.arrival);
        submitButton = (Button) findViewById(R.id.submitButton);
        results = (TextView) findViewById(R.id.results);
        results.setMovementMethod(new ScrollingMovementMethod());
        numTickets = (EditText) findViewById(R.id.numOfTickets);

        submitButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();


                mContext = getApplicationContext();
                mLoginHelper = new LoginHelper(mContext);
                boolean isValid = false;
                List<LoginItem> logs = mLoginHelper.getLogs();
                if (logs != null) {
                    for (LoginItem log : logs) {
                        if (username.equals(log.getName()) && password.equals(log.getPassword())) {
                            isValid = true;
                            break;
                        }
                        else if (username.equals("admin2") && password.equals("admin2")) {
                            isValid = true;
                            break;
                        }
                    }
                }
                if (!isValid) {
                    makeDialog("That is not a valid account! You will now be redirected to the Main Menu!", "Okay!", "Also Okay!", true);
                }
                else {
                    double price = flightItem.getPrice();
                    int tickets = Integer.parseInt(numTickets.getText().toString());
                    double total = price*tickets;
                    makeSpecialDialog("Username: "+username+flightItem.toString()+Integer.toString(tickets)+"\nReservation Number:"+Reservation.getNum()+"\nTotal Amount: $"+total+"\n",
                            "Confirm!", "Cancel!", true);
                }
            }
        });
        results.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView3.setVisibility(View.INVISIBLE);
                textView7.setVisibility(View.INVISIBLE);
                textView8.setVisibility(View.INVISIBLE);
                results.setVisibility(View.INVISIBLE);
                departure.setVisibility(View.INVISIBLE);
                arrival.setVisibility(View.INVISIBLE);
                submitButton.setVisibility(View.INVISIBLE);
                info.setVisibility(View.INVISIBLE);
                numTickets.setVisibility(View.INVISIBLE);

                submitButton2.setVisibility((View.VISIBLE));
                editUsername.setVisibility(View.VISIBLE);
                editPassword.setVisibility(View.VISIBLE);

            }
        });
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                results.setText("");
                String depart = String.valueOf(departure.getSelectedItem());
                String arr = String.valueOf(arrival.getSelectedItem());
                int numberTickets = Integer.parseInt(numTickets.getText().toString());
                List<FlightItem> flights = flight.getFlightList();
                List<LoginItem> logins = login.getLoginList();
                List<FlightItem> foundFlights = new ArrayList<>();
                for (FlightItem item : flights) {
                    if (item.getDeparture().equals(depart) && item.getArrival().equals(arr)) {
                        foundFlights.add(item);
                    }
                }
                boolean flag = true;
                if(foundFlights.isEmpty()) {
                    makeDialog("No flights are available for that journey! You will now be redirected to the Main Menu!", "Okay!",
                            "Also Okay", true);
                }
                else if (numberTickets > 7) {
                    makeDialog("The reservation can't be made due to a system restriction.", "Okay!", "Also Okay!", false);
                }
                else {
                    for (FlightItem item : foundFlights) {
                        if (flag) {
                            flightItem = item;
                            flag = false;
                        }
                        results.append("\n");
                        results.append("Flight number:\n");
                        results.append(item.getNumber());
                        results.append("\nDeparture:\n");
                        results.append(item.getDeparture());
                        results.append("\nArrival:\n");
                        results.append(item.getArrival());
                        results.append("\nDeparture Time:\n");
                        results.append(item.getTime());
                        results.append("\nFlight Capacity:\n");
                        results.append(Integer.toString(item.getCapacity()));
                        results.append("\nFlight Price:\n");
                        results.append(Double.toString(item.getPrice()).format("$%.2f",item.getPrice()));
                        results.append("\n");                    }
                }
            }
        });
    }


    public void makeLoginDialog(String message, final String accept, String deny, final boolean redirect) {
        final AlertDialog.Builder builder1 = new AlertDialog.Builder(ReserveSeatActivity.this);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                deny,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });

        builder1.setNegativeButton(
                accept,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            ReservationItem reservationItem = new ReservationItem();

                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    public void makeSpecialDialog(String message, final String accept, String deny, final boolean redirect) {
        final AlertDialog.Builder builder1 = new AlertDialog.Builder(ReserveSeatActivity.this);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                deny,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            makeDialog("You have chosen to cancel, you will now be redirected to the Main Menu!", "Okay!", "Also Okay!", true);
                        }
                    }
                });

        builder1.setNegativeButton(
                accept,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            makeDialog("Your reservation has been saved, you will now be returned to the main menu!", "Okay!", "Also Okay!", true);

                        }
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    public void makeDialog(String message, final String accept, String deny, final boolean redirect) {
        final AlertDialog.Builder builder1 = new AlertDialog.Builder(ReserveSeatActivity.this);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                deny,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

        builder1.setNegativeButton(
                accept,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
