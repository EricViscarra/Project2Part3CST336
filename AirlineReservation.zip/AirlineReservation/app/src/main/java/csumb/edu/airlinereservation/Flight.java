/**
 * Author: Eric Orozco Viscarra
 * Abstract: Helpful flight class that has useful methods
 * that will be used later to add flights to database and get
 * data from database
 * 12/16/18
 */
package csumb.edu.airlinereservation;

import android.content.Context;

import java.util.*;
import java.util.List;

import csumb.edu.airlinereservation.Database.FlightHelper;

public class Flight {
    private static Flight sFlight;
    private Context mContext;
    private FlightHelper mFlightHelper;

    public static Flight get(Context context) {
        if(sFlight == null) {
            sFlight = new Flight(context);
        }
        return sFlight;
    }

    private Flight(Context context) {
        mContext = context.getApplicationContext();
        mFlightHelper = new FlightHelper(mContext);
    }

    public long addLog(FlightItem Flight) {

        return mFlightHelper.addFlightItem(Flight);
    }

    public List<FlightItem> getFlightList() {

        return mFlightHelper.getLogs();
    }
    public String getLogString() {
        StringBuilder sb = new StringBuilder();
        List<FlightItem> logs = mFlightHelper.getLogs();
        if (logs == null) {
            return "Flight Logs null\n";
        }

        sb.append("Flight Logs:\n");

        for(FlightItem log : logs) {
            sb.append(log.toString());
        }

        return sb.toString();
    }
}
