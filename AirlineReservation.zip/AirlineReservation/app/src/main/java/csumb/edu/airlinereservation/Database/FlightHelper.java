/**
 * Author: Eric Orozco Viscarra
 * Abstract: Helps with adding flights to the flight database
 * Date: 12/16/2018
 */

package csumb.edu.airlinereservation.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import csumb.edu.airlinereservation.FlightItem;

public class FlightHelper extends SQLiteOpenHelper {

    private static final String TAG = "FlightLog";

    private static final int VERSION            = 1;
    public static final String DATABASE_NAME    = "flights.db";

    private SQLiteDatabase db;

    public FlightHelper(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + DatabaseSchema.FlightTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                DatabaseSchema.FlightTable.Cols.NUMBER     + "," +
                DatabaseSchema.FlightTable.Cols.DEPARTURE  + "," +
                DatabaseSchema.FlightTable.Cols.ARRIVAL    + "," +
                DatabaseSchema.FlightTable.Cols.TIME  + "," +
                DatabaseSchema.FlightTable.Cols.CAPACITY  + "," +
                DatabaseSchema.FlightTable.Cols.PRICE  + "," +
                DatabaseSchema.FlightTable.Cols.DATEADDED  + "," +
                DatabaseSchema.FlightTable.Cols.UUID       +
                ")"
        );
        FlightItem flight1 = new FlightItem("Otter101", "Monterey", "Los Angeles", "10:00(AM)", 10, 150.00);
        FlightItem flight2 = new FlightItem("Otter102", "Los Angeles", "Monterey", "01:00(PM)", 10, 150.00);
        FlightItem flight3 = new FlightItem("Otter201", "Monterey", "Seattle", "11:00(AM)", 5, 200.50);
        FlightItem flight4 = new FlightItem("Otter205", "Monterey", "Seattle", "03:00(PM)", 15, 150.00);
        FlightItem flight5 = new FlightItem("Otter202", "Seattle", "Monterey", "02:00(PM)", 5, 200.50);
        //FlightItem flight6 = new FlightItem("Otter301", "Los Angeles", "Seattle", "12:00(PM)", 10, 350.50);
        ContentValues cv1 = getContentValues(flight1);
        ContentValues cv2 = getContentValues(flight2);
        ContentValues cv3 = getContentValues(flight3);
        ContentValues cv4 = getContentValues(flight4);
        ContentValues cv5 = getContentValues(flight5);
        //ContentValues cv6 = getContentValues(flight6);
        db.insert(DatabaseSchema.FlightTable.NAME, null, cv1);
        db.insert(DatabaseSchema.FlightTable.NAME, null, cv2);
        db.insert(DatabaseSchema.FlightTable.NAME, null, cv3);
        db.insert(DatabaseSchema.FlightTable.NAME, null, cv4);
        db.insert(DatabaseSchema.FlightTable.NAME, null, cv5);
        //db.insert(DatabaseSchema.FlightTable.NAME, null, cv6);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //NYI
    }

    private long insertFlight(FlightItem Flight) {
        ContentValues cv = getContentValues(Flight);

        db = this.getWritableDatabase();

        return db.insert(DatabaseSchema.FlightTable.NAME, null, cv);
    }

    public long addFlightItem(FlightItem Flight) {
        if(this.getFlightItem(Flight.getIDnum()) == null) {
            return insertFlight(Flight);
        } else {
            return updateFlightItem(Flight);
        }
    }

    private int updateFlightItem(FlightItem Flight) {
        db = this.getWritableDatabase();
        ContentValues cv = FlightHelper.getContentValues(Flight);
        String whereClause = DatabaseSchema.FlightTable.Cols.UUID + " = ? ";
        String[] whereArgs = {Flight.getIDnum().toString()};
        try{
            return db.update(DatabaseSchema.FlightTable.NAME, cv, whereClause, whereArgs);
        } catch (Exception e) {
            Log.d(TAG, "something is wrong in updateFlightItem");
            return -1;
        }
    }

    private FlightItem getFlightItem(UUID logUUID) {
        String whereClause = DatabaseSchema.FlightTable.Cols.UUID + " = ? ";
        String[] whereArgs = {logUUID.toString()};

        DatabaseCursorWrapper cursor = new DatabaseCursorWrapper(this.queryDB(DatabaseSchema.FlightTable.NAME,whereClause,whereArgs));

        try {
            if (cursor.getCount() == 0) {
                Log.d(TAG, "No results from getFlightItem");
                return null;
            }
            cursor.moveToFirst();
            return cursor.getFlightItem();
        } finally {
            cursor.close();
        }
    }

    public List<FlightItem> getLogs() {
        List<FlightItem> logs = new ArrayList<>();
        DatabaseCursorWrapper cursor = new DatabaseCursorWrapper(this.queryDB(DatabaseSchema.FlightTable.NAME,null,null));
        try {
            if(cursor.getCount() == 0) {
                Log.d(TAG, "getFlightItems returned nothing...");
                return null;
            }
            cursor.moveToFirst();
            while(!cursor.isAfterLast()) {
                logs.add(cursor.getFlightItem());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }

        return logs;
    }

    private Cursor queryDB(String DBName, String whereClause, String[] whereArgs) {
        db = this.getWritableDatabase();

        try {
            return db.query(DatabaseSchema.FlightTable.NAME,
                    null,
                    whereClause,
                    whereArgs,
                    null,
                    null,
                    null);
        } catch (Exception e) {
            Log.d(TAG, "Problem in queryDB!!");
            return null;
        }
    }

    public static ContentValues getContentValues(FlightItem log) {
        ContentValues cv = new ContentValues();

        cv.put(DatabaseSchema.FlightTable.Cols.UUID, log.getIDnum().toString());
        cv.put(DatabaseSchema.FlightTable.Cols.NUMBER, log.getNumber());
        cv.put(DatabaseSchema.FlightTable.Cols.DEPARTURE, log.getDeparture());
        cv.put(DatabaseSchema.FlightTable.Cols.ARRIVAL, log.getArrival());
        cv.put(DatabaseSchema.FlightTable.Cols.TIME, log.getTime());
        cv.put(DatabaseSchema.FlightTable.Cols.CAPACITY, log.getCapacity());
        cv.put(DatabaseSchema.FlightTable.Cols.PRICE, log.getPrice());
        cv.put(DatabaseSchema.FlightTable.Cols.DATEADDED, log.getDateAdded().toString());

        return cv;
    }
}