/**
 * Author: Eric Orozco Viscarra
 * Abstract: One object item that helps with credentials and logging into the system
 * 12/16/18
 */

package csumb.edu.airlinereservation;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class LoginItem {

    private UUID IDnum;
    private String name;
    private String password;
    private int sqlLogId;
    public ArrayList<FlightItem> flights;

    private SimpleDateFormat ft = new SimpleDateFormat("M-dd-yyyy @ HH:mm:ss");
    private Date date;

    public LoginItem() {
        this.IDnum = UUID.randomUUID();
        this.date = new Date();
        flights = new ArrayList<>();
    }

    public LoginItem(String name, String password) {
        this.IDnum = UUID.randomUUID();
        this.date = new Date();
        this.name = name;
        this.password = password;
        Log.i("FlightLog", date.toString());
        flights = new ArrayList<>();
    }

    public LoginItem(UUID iD) {
        IDnum = iD;
        date = new Date();
        flights = new ArrayList<>();
    }

    public SimpleDateFormat getFt() {
        return ft;
    }

    public String getDateString() {
        return ft.format(date);
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public UUID getIDnum() {
        return IDnum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getSqlLogId() {
        return sqlLogId;
    }

    public void setSqlLogId(int sqlLogId) {
        this.sqlLogId = sqlLogId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append("Name: ").append(this.name).append("\n");
        sb.append("Password: ").append(this.password).append("\n");
        sb.append("Date: ").append(this.getDateString()).append("\n");
        sb.append("ID: ").append(this.getIDnum());

        return sb.toString();
    }
}
