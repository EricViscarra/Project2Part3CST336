/**
 * Author: Eric Orozco Viscarra
 * Abstract: After admin log in this is what they will see, log data
 * 12/16/18
 */
package csumb.edu.airlinereservation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class ManageSystemAdminActivity extends AppCompatActivity {
    TextView accountData;
    TextView flightData;

    LoginItem loginItem;
    Login login;

    FlightItem flightItem;
    Flight flight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_system_admin);
        accountData = (TextView) findViewById(R.id.loginData);
        flightData = (TextView) findViewById(R.id.flightData);
        accountData.setMovementMethod(new ScrollingMovementMethod());
        flightData.setMovementMethod(new ScrollingMovementMethod());

        login = Login.get(this.getApplicationContext());
        flight = Flight.get(this.getApplicationContext());

        List<FlightItem> flights = flight.getFlightList();
        List<LoginItem> logins = login.getLoginList();

        for (LoginItem item : logins) {
            accountData.append("\n");
            accountData.append("Name: ");
            accountData.append(item.getName());
            accountData.append("\n");
            accountData.append("Date created: \n");
            accountData.append(item.getDateString());
            accountData.append("\n");
        }
        accountData.append("\n\n\n");
        for (FlightItem item : flights) {
            flightData.append("\n");
            flightData.append("Flight number:\n");
            flightData.append(item.getNumber());
            flightData.append("\nDeparture:\n");
            flightData.append(item.getDeparture());
            flightData.append("\nArrival:\n");
            flightData.append(item.getArrival());
            flightData.append("\nDeparture Time:\n");
            flightData.append(item.getTime());
            flightData.append("\nFlight Capacity:\n");
            flightData.append(Integer.toString(item.getCapacity()));
            flightData.append("\nFlight Price:\n");
            flightData.append(Double.toString(item.getPrice()).format("$%.2f",item.getPrice()));
            flightData.append("\nDate created:\n");
            flightData.append(item.getDateString());
            flightData.append("\n");
        }
        flightData.append("\n\n\n");
    }

    public void addFlightInfo(View view) {
        Intent intent = new Intent(this, AddFlightActivity.class);
        startActivity(intent);
    }
}
