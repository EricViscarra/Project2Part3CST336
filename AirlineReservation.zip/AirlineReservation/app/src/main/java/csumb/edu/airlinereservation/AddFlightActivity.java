/**
 * Author: Eric Orozco Viscarra
 * Abstract: Allows admin to make a flight
 * 12/16/18
 */
package csumb.edu.airlinereservation;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.List;

public class AddFlightActivity extends AppCompatActivity {
    EditText number;
    EditText departure;
    EditText arrival;
    EditText time;
    EditText capacity;
    EditText price;
    Button submitButton;

    FlightItem flightItem;
    Flight flightLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_flight);

        number = (EditText) findViewById(R.id.number);
        departure = (EditText) findViewById(R.id.departure);
        arrival = (EditText) findViewById(R.id.arrival);
        time = (EditText) findViewById(R.id.time);
        capacity = (EditText) findViewById(R.id.capacity);
        price = (EditText) findViewById(R.id.price);
        submitButton = (Button) findViewById(R.id.submitButton);
        flightLog = Flight.get(this.getApplicationContext());

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String flightNumber = number.getText().toString();
                String departureCity = departure.getText().toString();
                String arrivalCity = arrival.getText().toString();
                String timeOfDay = time.getText().toString();
                int capacitance = Integer.parseInt(capacity.getText().toString());
                double pricey = Double.parseDouble(price.getText().toString());
                FlightItem flight = createFlightItem(flightNumber, departureCity, arrivalCity, timeOfDay, capacitance, pricey);
                List<FlightItem> flights = flightLog.getFlightList();
                boolean found = false;
                for (FlightItem item : flights) {
                    if (item.getNumber().equals(flightNumber))
                        found = true;
                }
                if (!found) {
                    makeDialog("Are you sure you want to add the flight info?", "Yes!", "No!", true);
                    flightLog.addLog(flight);
                } else {
                    makeSpecialDialog("That Flight already exists! You will now be returned to the main menu!", "Okay!", "Also Okay!", true);

                }
            }
        });
    }

    public void makeSpecialDialog(String message, final String accept, String deny, final boolean redirect) {
        final AlertDialog.Builder builder1 = new AlertDialog.Builder(AddFlightActivity.this);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                deny,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            makeDialog("Flight Info has been added! Now returning to main menu!", "Okay!", "Also Okay!", true);
                        }
                    }
                });

        builder1.setNegativeButton(
                accept,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            makeDialog("You said no so you will now be returned to the main menu!", "Okay!", "Also Okay!", true);
                        }
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private FlightItem createFlightItem(String number, String departure, String arrival, String time, int capacity, double price) {
        FlightItem flight = new FlightItem(number, departure, arrival, time, capacity, price);
        return flight;
    }

    public void makeDialog(String message, final String accept, String deny, final boolean redirect) {
        final AlertDialog.Builder builder1 = new AlertDialog.Builder(AddFlightActivity.this);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                deny,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

        builder1.setNegativeButton(
                accept,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
