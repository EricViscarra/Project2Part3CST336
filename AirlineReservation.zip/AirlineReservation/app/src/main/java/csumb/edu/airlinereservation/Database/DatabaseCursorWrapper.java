/**
 * Author: Eric Orozco Viscarra
 * Abstract: Helps with database inquiries
 * 12/16/18
 */
package csumb.edu.airlinereservation.Database;

import android.database.Cursor;
import android.database.CursorWrapper;
import java.util.Date;
import java.util.UUID;

import csumb.edu.airlinereservation.FlightItem;
import csumb.edu.airlinereservation.LoginItem;
import csumb.edu.airlinereservation.Reservation;
import csumb.edu.airlinereservation.ReservationItem;


public class DatabaseCursorWrapper extends CursorWrapper {
    public DatabaseCursorWrapper(Cursor cursor){
        super(cursor);
    }

    public FlightItem getFlightItem() {
        String uuidString = getString(getColumnIndex(DatabaseSchema.FlightTable.Cols.UUID));
        String number = getString(getColumnIndex(DatabaseSchema.FlightTable.Cols.NUMBER));
        String departure = getString(getColumnIndex(DatabaseSchema.FlightTable.Cols.DEPARTURE));
        String arrival = getString(getColumnIndex(DatabaseSchema.FlightTable.Cols.ARRIVAL));
        String time = getString(getColumnIndex(DatabaseSchema.FlightTable.Cols.TIME));
        int capacity = getInt(getColumnIndex(DatabaseSchema.FlightTable.Cols.CAPACITY));
        double price = getDouble(getColumnIndex(DatabaseSchema.FlightTable.Cols.PRICE));
        Date date = new Date(getString(getColumnIndex(DatabaseSchema.FlightTable.Cols.DATEADDED)));
        int sqlLogId = getInt(getColumnIndex("_id"));

        FlightItem flight = new FlightItem(UUID.fromString(uuidString));

        flight.setNumber(number);
        flight.setDeparture(departure);
        flight.setArrival(arrival);
        flight.setTime(time);
        flight.setCapacity(capacity);
        flight.setPrice(price);
        flight.setSqlLogId(sqlLogId);
        flight.setDateAdded(date);

        return flight;
    }

    public LoginItem getLoginItem() {
        String uuidString = getString(getColumnIndex(DatabaseSchema.LoginTable.Cols.UUID));
        String name = getString(getColumnIndex(DatabaseSchema.LoginTable.Cols.USERNAME));
        String password = getString(getColumnIndex(DatabaseSchema.LoginTable.Cols.PASSWORD));
        int sqlLogId = getInt(getColumnIndex("_id"));

        Date date = new Date(getString(getColumnIndex(DatabaseSchema.LoginTable.Cols.DATE)));

        LoginItem acc = new LoginItem(UUID.fromString(uuidString));

        acc.setPassword(password);
        acc.setName(name);
        acc.setDate(date);
        acc.setSqlLogId(sqlLogId);

        return acc;
    }

    public ReservationItem getReservationItem() {
        String uuidString = getString(getColumnIndex(DatabaseSchema.ReservationTable.Cols.UUID));
        String username = getString(getColumnIndex(DatabaseSchema.ReservationTable.Cols.USERNAME));
        String flightnumber = getString(getColumnIndex(DatabaseSchema.ReservationTable.Cols.FLIGHTNUMBER));
        String departure = getString(getColumnIndex(DatabaseSchema.ReservationTable.Cols.DEPARTURE));
        String arrival = getString(getColumnIndex(DatabaseSchema.ReservationTable.Cols.ARRIVAL));
        String tickets = getString(getColumnIndex(DatabaseSchema.ReservationTable.Cols.TICKETS));
        String reservationnumber = getString(getColumnIndex(DatabaseSchema.ReservationTable.Cols.RESERVATIONNUMBER));
        String price = getString(getColumnIndex(DatabaseSchema.ReservationTable.Cols.PRICE));

        int sqlLogId = getInt(getColumnIndex("_id"));

        ReservationItem reserve = new ReservationItem(UUID.fromString(uuidString));

        reserve.setUsername(username);
        reserve.setFlightnumber(flightnumber);
        reserve.setDeparture(departure);
        reserve.setArrival(arrival);
        reserve.setTickets(tickets);
        reserve.setReservationnumber(reservationnumber);
        reserve.setPrice(price);

        reserve.setSqlLogId(sqlLogId);

        return reserve;
    }
}
