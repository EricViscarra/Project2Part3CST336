/**
 * Author: Eric Orozco Viscarra
 * Abstract: Helps with account credentials and databases
 * Date: 12/16/2018
 */

package csumb.edu.airlinereservation.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.ContactsContract;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import csumb.edu.airlinereservation.LoginItem;

public class LoginHelper extends SQLiteOpenHelper {

    private static final String TAG = "FlightLog";

    private static final int VERSION            = 1;
    public static final String DATABASE_NAME    = "accountLog.db";

    private SQLiteDatabase db;

    public LoginHelper(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + DatabaseSchema.LoginTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                DatabaseSchema.LoginTable.Cols.USERNAME + "," +
                DatabaseSchema.LoginTable.Cols.PASSWORD + "," +
                DatabaseSchema.LoginTable.Cols.DATE + "," +
                DatabaseSchema.LoginTable.Cols.UUID +
                ")"
        );
        LoginItem acc1 = new LoginItem("alice5", "csumb100");
        LoginItem acc2 = new LoginItem("brian77", "123ABC");
        LoginItem acc3 = new LoginItem("chris21", "CHRIS21");

        ContentValues cv1 = getContentValues(acc1);
        ContentValues cv2 = getContentValues(acc2);
        ContentValues cv3 = getContentValues(acc3);

        db.insert(DatabaseSchema.LoginTable.NAME, null, cv1);
        db.insert(DatabaseSchema.LoginTable.NAME, null, cv2);
        db.insert(DatabaseSchema.LoginTable.NAME, null, cv3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //NYI
    }

    private long insertLogin(LoginItem account) {
        ContentValues cv = getContentValues(account);

        db = this.getWritableDatabase();

        return db.insert(DatabaseSchema.LoginTable.NAME, null, cv);
    }

    public long addLoginItem(LoginItem account) {
        if(this.getLoginItem(account.getIDnum()) == null) {
            return insertLogin(account);
        } else {
            return updateLoginItem(account);
        }
    }

    private int updateLoginItem(LoginItem account) {
        db = this.getWritableDatabase();
        ContentValues cv = LoginHelper.getContentValues(account);
        String whereClause = DatabaseSchema.LoginTable.Cols.UUID + " = ? ";
        String[] whereArgs = {account.getIDnum().toString()};
        try{
            return db.update(DatabaseSchema.LoginTable.NAME, cv, whereClause, whereArgs);
        } catch (Exception e) {
            Log.d(TAG, "something is wrong in updateLoginItem");
            return -1;
        }
    }

    private LoginItem getLoginItem(UUID logUUID) {
        String whereClause = DatabaseSchema.LoginTable.Cols.UUID + " = ? ";
        String[] whereArgs = {logUUID.toString()};

        DatabaseCursorWrapper cursor = new DatabaseCursorWrapper(this.queryDB(DatabaseSchema.LoginTable.NAME,whereClause,whereArgs));

        try {
            if (cursor.getCount() == 0) {
                Log.d(TAG, "No results from getLoginItem");
                return null;
            }
            cursor.moveToFirst();
            return cursor.getLoginItem();
        } finally {
            cursor.close();
        }
    }

    public List<LoginItem> getLogs() {
        List<LoginItem> logs = new ArrayList<>();
        DatabaseCursorWrapper cursor = new DatabaseCursorWrapper(this.queryDB(DatabaseSchema.LoginTable.NAME,null,null));
        try {
            if(cursor.getCount() == 0) {
                Log.d(TAG, "getLoginItems returned nothing...");
                return null;
            }
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                logs.add(cursor.getLoginItem());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }

        return logs;
    }

    private Cursor queryDB(String DBName, String whereClause, String[] whereArgs){
        db = this.getWritableDatabase();

        try{
            return db.query(DatabaseSchema.LoginTable.NAME,
                    null,
                    whereClause,
                    whereArgs,
                    null,
                    null,
                    null);
        }catch (Exception e) {
            Log.d(TAG, "Problem in queryDB!!");
            return null;
        }
    }

    public static ContentValues getContentValues(LoginItem log) {
        ContentValues cv = new ContentValues();
        cv.put(DatabaseSchema.LoginTable.Cols.UUID, log.getIDnum().toString());
        cv.put(DatabaseSchema.LoginTable.Cols.USERNAME, log.getName().toString());
        cv.put(DatabaseSchema.LoginTable.Cols.DATE, log.getDate().toString());
        cv.put(DatabaseSchema.LoginTable.Cols.PASSWORD, log.getPassword().toString());
        return cv;
    }
}
