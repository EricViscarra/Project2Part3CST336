/**
 * Author: Eric Orozco Viscarra
 * Abstract: Holds methods used by other login attempting activites
 * 12/16/18
 */
package csumb.edu.airlinereservation;

import android.content.Context;

import java.util.List;

import csumb.edu.airlinereservation.Database.LoginHelper;

public class Login {
    private static Login sLogin;
    private Context mContext;
    private LoginHelper mLoginHelper;

    public static Login get(Context context) {
        if(sLogin == null) {
            sLogin = new Login(context);
        }
        return sLogin;
    }

    private Login(Context context) {
        mContext = context.getApplicationContext();
        mLoginHelper = new LoginHelper(mContext);
    }

    public long addLog(LoginItem account) {
        return mLoginHelper.addLoginItem(account);
    }

    public List<LoginItem> getLoginList() {

        return mLoginHelper.getLogs();

    }

    public String getLogString() {
        StringBuilder sb = new StringBuilder();
        List<LoginItem> logs = mLoginHelper.getLogs();
        if (logs == null) {
            return "Login Logs null\n";
        }

        sb.append("Login Logs:\n");

        for(LoginItem log : logs) {
            sb.append(log.toString());
        }

        return sb.toString();
    }
}
