/**
 * Author: Eric Orozco Viscarra
 * Abstract: Should of allowed user to cancel a reservation
 * 12/16/18
 */

package csumb.edu.airlinereservation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CancelReservationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_reservation);
    }
}
