/**
 * Author: Eric Orozco Viscarra
 * Abstract: Helps with adding flights to the flight database
 * Date: 12/16/2018
 */

package csumb.edu.airlinereservation.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import csumb.edu.airlinereservation.ReservationItem;

public class ReservationHelper extends SQLiteOpenHelper {

    private static final String TAG = "ReservationLog";

    private static final int VERSION            = 1;
    public static final String DATABASE_NAME    = "reservations.db";

    private SQLiteDatabase db;

    public ReservationHelper(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + DatabaseSchema.ReservationTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                DatabaseSchema.ReservationTable.Cols.USERNAME     + "," +
                DatabaseSchema.ReservationTable.Cols.FLIGHTNUMBER  + "," +
                DatabaseSchema.ReservationTable.Cols.DEPARTURE    + "," +
                DatabaseSchema.ReservationTable.Cols.ARRIVAL  + "," +
                DatabaseSchema.ReservationTable.Cols.TICKETS  + "," +
                DatabaseSchema.ReservationTable.Cols.RESERVATIONNUMBER  + "," +
                DatabaseSchema.ReservationTable.Cols.PRICE  + "," +
                DatabaseSchema.ReservationTable.Cols.UUID       +
                ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //NYI
    }

    private long insertReservation(ReservationItem Reservation) {
        ContentValues cv = getContentValues(Reservation);

        db = this.getWritableDatabase();

        return db.insert(DatabaseSchema.ReservationTable.NAME, null, cv);
    }

    public long addReservationItem(ReservationItem Reservation) {
        if(this.getReservationItem(Reservation.getIDnum()) == null) {
            return insertReservation(Reservation);
        } else {
            return updateReservationItem(Reservation);
        }
    }

    private int updateReservationItem(ReservationItem Reservation) {
        db = this.getWritableDatabase();
        ContentValues cv = ReservationHelper.getContentValues(Reservation);
        String whereClause = DatabaseSchema.ReservationTable.Cols.UUID + " = ? ";
        String[] whereArgs = {Reservation.getIDnum().toString()};
        try{
            return db.update(DatabaseSchema.ReservationTable.NAME, cv, whereClause, whereArgs);
        } catch (Exception e) {
            Log.d(TAG, "something is wrong in updateReservationItem");
            return -1;
        }
    }

    private ReservationItem getReservationItem(UUID logUUID) {
        String whereClause = DatabaseSchema.ReservationTable.Cols.UUID + " = ? ";
        String[] whereArgs = {logUUID.toString()};

        DatabaseCursorWrapper cursor = new DatabaseCursorWrapper(this.queryDB(DatabaseSchema.ReservationTable.NAME,whereClause,whereArgs));

        try {
            if (cursor.getCount() == 0) {
                Log.d(TAG, "No results from getReservationItem");
                return null;
            }
            cursor.moveToFirst();
            return cursor.getReservationItem();
        } finally {
            cursor.close();
        }
    }

    public List<ReservationItem> getLogs() {
        List<ReservationItem> logs = new ArrayList<>();
        DatabaseCursorWrapper cursor = new DatabaseCursorWrapper(this.queryDB(DatabaseSchema.ReservationTable.NAME,null,null));
        try {
            if(cursor.getCount() == 0) {
                Log.d(TAG, "getReservationItems returned nothing...");
                return null;
            }
            cursor.moveToFirst();
            while(!cursor.isAfterLast()) {
                logs.add(cursor.getReservationItem());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }

        return logs;
    }

    private Cursor queryDB(String DBName, String whereClause, String[] whereArgs) {
        db = this.getWritableDatabase();

        try {
            return db.query(DatabaseSchema.ReservationTable.NAME,
                    null,
                    whereClause,
                    whereArgs,
                    null,
                    null,
                    null);
        } catch (Exception e) {
            Log.d(TAG, "Problem in queryDB!!");
            return null;
        }
    }

    public static ContentValues getContentValues(ReservationItem log) {
        ContentValues cv = new ContentValues();

        cv.put(DatabaseSchema.ReservationTable.Cols.UUID, log.getIDnum().toString());
        cv.put(DatabaseSchema.ReservationTable.Cols.USERNAME, log.getUsername());
        cv.put(DatabaseSchema.ReservationTable.Cols.FLIGHTNUMBER, log.getFlightnumber());
        cv.put(DatabaseSchema.ReservationTable.Cols.DEPARTURE, log.getDeparture());
        cv.put(DatabaseSchema.ReservationTable.Cols.ARRIVAL, log.getArrival());
        cv.put(DatabaseSchema.ReservationTable.Cols.TICKETS, log.getTickets());
        cv.put(DatabaseSchema.ReservationTable.Cols.RESERVATIONNUMBER, log.getReservationnumber());
        cv.put(DatabaseSchema.ReservationTable.Cols.PRICE, log.getPrice());

        return cv;
    }
}