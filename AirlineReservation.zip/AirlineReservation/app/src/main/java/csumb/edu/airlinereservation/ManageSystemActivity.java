/**
 * Author: Eric Orozco Viscarra
 * Abstract: Allows user to see what has happened in the system
 * 12/16/18
 */

package csumb.edu.airlinereservation;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ManageSystemActivity extends AppCompatActivity {

    EditText editLoginName;
    EditText editPassword;
    Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_system);

        editLoginName  = (EditText) findViewById(R.id.editLoginName);
        editPassword  = (EditText) findViewById(R.id.editPassword);
        submitButton = (Button) findViewById(R.id.submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    if (checkField(editLoginName.getText().toString())
                            && checkField(editPassword.getText().toString())) {
                        String username = editLoginName.getText().toString();
                        String password = editPassword.getText().toString();
                        if (username.equals("admin2") && password.equals("admin2")) {
                            login(view);
                        }
                    } else {
                        makeDialog("Invalid account information, you will now be returned to the MainMenu!", "Okay!", "Also Okay!", true);
                    }

            }
        });
    }

    public void login (View view) {
        Intent intent = new Intent(this, ManageSystemAdminActivity.class);
        startActivity(intent);
    }

    public void makeDialog(String message, final String accept, String deny, final boolean redirect) {
        final AlertDialog.Builder builder1 = new AlertDialog.Builder(ManageSystemActivity.this);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                deny,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

        builder1.setNegativeButton(
                accept,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private boolean checkField(String field) {
        char[] word = field.toCharArray();
        int character = 0;
        int digit = 0;
        for (char item : word) {
            if (Character.isLetter(item))
                character++;
            else if (Character.isDigit(item))
                digit++;
        }
        if (character >= 3 && digit >= 1)
            return true;
        return false;
    }

}
