/**
 * Author: Eric Orozco Viscarra
 * Abstract: One object item that helps with credentials and logging into the system
 * 12/16/18
 */

package csumb.edu.airlinereservation;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class ReservationItem {

    private UUID IDnum;
    private String username;
    private String flightnumber;
    private String departure;
    private String arrival;
    private String tickets;
    private String reservationnumber;
    private String price;
    private int sqlLogId;
    public ArrayList<ReservationItem> reservations;

    public ReservationItem() {
        this.IDnum = UUID.randomUUID();
        reservations = new ArrayList<>();
    }

    public ReservationItem(String name, String password) {
        this.IDnum = UUID.randomUUID();
        reservations = new ArrayList<>();
    }

    public ReservationItem(UUID iD) {
        IDnum = iD;
        reservations = new ArrayList<>();
    }



    public UUID getIDnum() {
        return IDnum;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getReservationnumber() {

        return reservationnumber;
    }

    public void setReservationnumber(String reservationnumber) {
        this.reservationnumber = reservationnumber;
    }

    public String getTickets() {

        return tickets;
    }

    public void setTickets(String tickets) {
        this.tickets = tickets;
    }

    public String getArrival() {

        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public String getDeparture() {

        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getFlightnumber() {

        return flightnumber;
    }

    public void setFlightnumber(String flightnumber) {
        this.flightnumber = flightnumber;
    }

    public String getUsername() {

        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getSqlLogId() {
        return sqlLogId;
    }

    public void setSqlLogId(int sqlLogId) {
        this.sqlLogId = sqlLogId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append("Username: ").append(this.username).append("\n");
        sb.append("Flight number: ").append(this.flightnumber).append("\n");
        sb.append("Departure: ").append(this.departure).append("\n");
        sb.append("Arrival: ").append(this.getArrival());
        sb.append("Number of tickets: ").append(this.tickets);
        sb.append("Reservation Number: ").append(this.reservationnumber);
        sb.append("Total Amount: ").append(this.price);

        return sb.toString();
    }
}
