/**
 * Author: Eric Orozco Viscarra
 * Abstract: Holds info about base tables in the database
 * 12/16/18
 */

package csumb.edu.airlinereservation.Database;

public class DatabaseSchema {
    public static final class LoginTable {
        public static final String NAME = "LOGINS";

        public static final class Cols {
            public static final String UUID     = "uuid";
            public static final String USERNAME     = "username";
            public static final String PASSWORD   = "password";
            public static final String DATE     = "date";
        }
    }

    public static final class FlightTable {
        public static final String NAME = "FLIGHTS";

        public static final class Cols {
            public static final String UUID         = "uuid";
            public static final String NUMBER       = "number";
            public static final String DEPARTURE    = "departure";
            public static final String ARRIVAL      = "arrival";
            public static final String TIME         = "time";
            public static final String CAPACITY     = "capacity";
            public static final String PRICE        = "price";
            public static final String DATEADDED    = "dateadded";
        }
    }

    public static final class ReservationTable {
        public static final String NAME = "RESERVATIONS";

        public static final class Cols {
            public static final String UUID         = "uuid";
            public static final String USERNAME       = "username";
            public static final String FLIGHTNUMBER    = "flightnumber";
            public static final String DEPARTURE      = "departure";
            public static final String ARRIVAL         = "arrival";
            public static final String TICKETS     = "tickets";
            public static final String RESERVATIONNUMBER        = "reservationnumber";
            public static final String PRICE    = "price";
        }
    }
}