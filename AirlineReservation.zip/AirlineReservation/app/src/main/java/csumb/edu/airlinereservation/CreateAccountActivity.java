/**
 * Author: Eric Orozco Viscarra
 * Abstract: Activity that allows user to make an account
 * 12/16/18
 */
package csumb.edu.airlinereservation;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

import csumb.edu.airlinereservation.Database.LoginHelper;

public class CreateAccountActivity extends AppCompatActivity {

    private Context mContext;
    private boolean failedOnce = false;
    EditText editLoginName;
    EditText editPassword;
    Button submitButton;

    LoginItem loginItem;
    Login accountLog;
    LoginHelper mLoginHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        editLoginName  = (EditText) findViewById(R.id.editLoginName);
        editPassword  = (EditText) findViewById(R.id.editPassword);
        submitButton = (Button) findViewById(R.id.submitButton);
        accountLog = Login.get(this.getApplicationContext());

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = editLoginName.getText().toString();
                String password = editPassword.getText().toString();
                int countLetter = 0;
                int countNumber = 0;
                boolean isNotValid = false;
                for (int i = 0; i < username.length(); i++) {
                    if (Character.isLetter(username.charAt(i))) {
                        countLetter++;
                    } else if (Character.isDigit(username.charAt(i))) {
                        countNumber++;
                    }
                }
                if (countLetter < 3 || countNumber < 1 || username.equals("admin2")) {
                    isNotValid = true;
                }

                countLetter = 0;
                countNumber = 0;
                for (int i = 0; i < password.length(); i++) {
                    if (Character.isLetter(password.charAt(i))) {
                        countLetter++;
                    } else if (Character.isDigit(password.charAt(i))) {
                        countNumber++;
                    }
                }
                if (countLetter < 3 || countNumber < 1) {
                    isNotValid = true;
                }

                mContext = getApplicationContext();
                mLoginHelper = new LoginHelper(mContext);
                List<LoginItem> logs = mLoginHelper.getLogs();
                if (logs != null) {
                    for (LoginItem log : logs) {
                        if (log.getName().equals(username)) {
                            isNotValid = true;
                            break;
                        }
                    }
                }


                if (isNotValid) {
                    if (failedOnce) {
                        makeDialog("That Username/Password is also invalid! You will now be redirected to the main menu!",
                                "Okay!",
                                "Also Okay!",
                                failedOnce);
                    }
                    else {
                        makeDialog("That Username/Password is invalid, please try again!",
                                "Okay!",
                                "Also Okay!",
                                failedOnce);
                        failedOnce = true;
                    }

                }
                else {
                    makeDialog("Account Successfully Created!",
                            "Okay!",
                            "Also Okay!",
                            true);
                    LoginItem loginItem = new LoginItem();

                    loginItem.setName(username);
                    loginItem.setPassword(password);
                    Login login;
                    login = Login.get(getApplicationContext());
                    login.addLog(loginItem);
                }
//                tempTextView.setText(accountLog.getLogString());
            }
        });
    }

    private boolean isEmpty(EditText textToCheck) {
        return textToCheck.getText().toString().trim().length() == 0;
    }
    public void makeDialog(String message, final String accept, String deny, final boolean redirect) {
        final AlertDialog.Builder builder1 = new AlertDialog.Builder(CreateAccountActivity.this);
        builder1.setMessage(message);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                deny,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

        builder1.setNegativeButton(
                accept,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        if (redirect) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        }
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
