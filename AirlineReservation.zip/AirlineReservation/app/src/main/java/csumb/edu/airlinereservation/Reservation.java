/**
 * Author: Eric Orozco Viscarra
 * Abstract: Helpful flight class that has useful methods
 * that will be used later to add flights to database and get
 * data from database
 * 12/16/18
 */
package csumb.edu.airlinereservation;

import android.content.Context;

import java.util.List;

import csumb.edu.airlinereservation.Database.ReservationHelper;
import csumb.edu.airlinereservation.ReservationItem;

public class Reservation {
    public static int num = 0;
    private static Reservation sReservation;
    private Context mContext;
    private ReservationHelper mReservationHelper;

    public static Reservation get(Context context) {
        if(sReservation == null) {
            sReservation = new Reservation(context);
        }
        return sReservation;
    }

    private Reservation(Context context) {
        mContext = context.getApplicationContext();
        mReservationHelper = new ReservationHelper(mContext);
    }

    public long addLog(ReservationItem reservation) {

        return mReservationHelper.addReservationItem(reservation);
    }

    public List<ReservationItem> getReservationList() {

        return mReservationHelper.getLogs();
    }
    public String getLogString() {
        StringBuilder sb = new StringBuilder();
        List<ReservationItem> logs = mReservationHelper.getLogs();
        if (logs == null) {
            return "Reservation Logs null\n";
        }

        sb.append("Reservation Logs:\n");

        for(ReservationItem log : logs) {
            sb.append(log.toString());
        }

        return sb.toString();
    }

    public static int getNum() {
        num++;
        return num;
    }
}
